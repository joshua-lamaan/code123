function calculateIncome() {
	var hourlyRate = parseFloat(document.getElementById("hourly-rate").value) || 0;
	var hoursPerDay = parseFloat(document.getElementById("hours-per-day").value) || 0;
	var dailyIncome = hourlyRate * hoursPerDay;
	var monthlyIncome = dailyIncome * 22; 
	var yearlyIncome = dailyIncome * 260; 

	document.getElementById("daily-income").textContent = dailyIncome.toFixed(2);
	document.getElementById("monthly-income").textContent = monthlyIncome.toFixed(2);
	document.getElementById("yearly-income").textContent = yearlyIncome.toFixed(2);
}